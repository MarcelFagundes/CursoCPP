#include <concepts>
#include <iostream>
#include <memory>
#include <sstream>

#include "expression.hpp"
#include "operations.hpp"


int main()
{
    using namespace calc;
    using namespace calc::operations;

    Expression a = Add(Number{3.0}, Number{6.0});

    std::cout << a.eval() << '\n';
}
