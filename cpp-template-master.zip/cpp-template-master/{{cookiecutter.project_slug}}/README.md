{{cookiecutter.project_name}}
{% for _ in cookiecutter.project_name %}={% endfor %}
